exports.ATKAZ = "Atkaz qildi";
exports.PULIYUQ = "Puli yuq ekan";
exports.MAHSULOTYOQMADI = "Mahsulot yoqmadi";
exports.TELEFONKOTARMADI = "Telefonini ko'tarmadi";
exports.ZAKAZQILINMAGAN = "Buyurtma bermagan ekan";
