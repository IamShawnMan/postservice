exports.ORTIQCHAXARAJAT = "Ortiqcha xarajat bor";
exports.TUMANGAJONATILDI = "Tumanga jo`natildi";
exports.JAVOBBERMADI = "Telefoniga javob bermayapti";
exports.ERTAGAOLARKAN = "Ertaga olar ekan";
