exports.RAHBAR = "RAHBAR";
exports.ADMIN = "ADMIN";
exports.FIRMA = "FIRMA";
exports.KURIER = "VILOYAT BOSHLIG`I";
