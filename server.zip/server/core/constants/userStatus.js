exports.ACTIVE = "ACTIVE"
exports.BLOCKED = "BLOCKED"